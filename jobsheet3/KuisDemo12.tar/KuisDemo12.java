public class KuisDemo12 {
    public static void main(String[] args) {
        Kuis12[] arrayOfMahasiswa12 = new Kuis12[3];
        arrayOfMahasiswa12[0] = new Kuis12();
        arrayOfMahasiswa12[0].nim = "2411";
        arrayOfMahasiswa12[0].nama = "Endra";
        arrayOfMahasiswa12[0].nilaiKuis = (double)73.4 ;
        arrayOfMahasiswa12[0].nilaiUTS= (double)88.4 ;
        arrayOfMahasiswa12[0].nilaiUAS = (double) 82.9 ;

        arrayOfMahasiswa12[1] = new Kuis12();
        arrayOfMahasiswa12[1].nim = "2468";
        arrayOfMahasiswa12[1].nama = "Lely";
        arrayOfMahasiswa12[0].nilaiKuis = (double)80.1 ;
        arrayOfMahasiswa12[0].nilaiUTS= (double)85.9 ;
        arrayOfMahasiswa12[0].nilaiUAS = (double) 79.6 ;


        arrayOfMahasiswa12[2] = new Kuis12();
        arrayOfMahasiswa12[2].nim = "2473";
        arrayOfMahasiswa12[2].nama = "Yuni";
        arrayOfMahasiswa12[0].nilaiKuis = (double)91.2 ;
        arrayOfMahasiswa12[0].nilaiUTS= (double)90.3 ;
        arrayOfMahasiswa12[0].nilaiUAS = (double) 85.3 ;


        arrayOfMahasiswa12[2] = new Kuis12();
        arrayOfMahasiswa12[2].nim = "2479";
        arrayOfMahasiswa12[2].nama = "Roma";
        arrayOfMahasiswa12[0].nilaiKuis = (double)88.5 ;
        arrayOfMahasiswa12[0].nilaiUTS= (double)88.4 ;
        arrayOfMahasiswa12[0].nilaiUAS = (double) 80.2 ;


        System.out.println("NIM     : " + arrayOfMahasiswa12[0].nim);
        System.out.println("Nama    : " + arrayOfMahasiswa12[0].nama);
        System.out.println("nilaiKuis    : " + arrayOfMahasiswa12[0].nilaiKuis);
        System.out.println("nilaiUTS     : " + arrayOfMahasiswa12[0].nilaiUTS);
        System.out.println("nilaiUAS     : " + arrayOfMahasiswa12[0].nilaiUAS);
        System.out.println("-------------------------------------");
        System.out.println("NIM     : " + arrayOfMahasiswa12[0].nim);
        System.out.println("Nama    : " + arrayOfMahasiswa12[0].nama);
        System.out.println("nilaiKuis    : " + arrayOfMahasiswa12[0].nilaiKuis);
        System.out.println("nilaiUTS     : " + arrayOfMahasiswa12[0].nilaiUTS);
        System.out.println("nilaiUAS     : " + arrayOfMahasiswa12[0].nilaiUAS);
        System.out.println("--------------------------------------");
        System.out.println("NIM     : " + arrayOfMahasiswa12[0].nim);
        System.out.println("Nama    : " + arrayOfMahasiswa12[0].nama);
        System.out.println("nilaiKuis    : " + arrayOfMahasiswa12[0].nilaiKuis);
        System.out.println("nilaiUTS     : " + arrayOfMahasiswa12[0].nilaiUTS);
        System.out.println("nilaiUAS     : " + arrayOfMahasiswa12[0].nilaiUAS);
        System.out.println("--------------------------------------");
        System.out.println("NIM     : " + arrayOfMahasiswa12[0].nim);
        System.out.println("Nama    : " + arrayOfMahasiswa12[0].nama);
        System.out.println("nilaiKuis    : " + arrayOfMahasiswa12[0].nilaiKuis);
        System.out.println("nilaiUTS     : " + arrayOfMahasiswa12[0].nilaiUTS);
        System.out.println("nilaiUAS     : " + arrayOfMahasiswa12[0].nilaiUAS);
        System.out.println("--------------------------------------");



    }
}